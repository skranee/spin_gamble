export { default } from './SingleMine';
